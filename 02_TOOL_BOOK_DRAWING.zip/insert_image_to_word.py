from docx import Document
from docx.shared import Inches
import os
import datetime
from PIL import Image
from docx import Document
from docx.shared import Inches
import shutil
import threading

if __name__ == "__main__":
    # create file word
    document = Document()
    document.add_page_break()
    # document.add_page_break()
    numberHeading = 1
    listFolderResize = os.listdir(os.getcwd() + "/resized")
    for folder in listFolderResize:
        # print(folder)
        document.add_heading(text=numberHeading.__str__() + ". " + folder, level=1)
        # p = document.add_paragraph()
        # r = p.add_run()
        listImage = sorted(os.listdir(os.getcwd() + "/resized/" + folder))
        for image in listImage:
            document.add_picture(os.getcwd() + "/resized/" + folder + '/' +  image,width=Inches(6))
        numberHeading += 1
    folder_name = folder
    document.save(os.getcwd() + "/" + "docx" + "/" + folder_name + " " + datetime.datetime.now().__str__()[:19].replace(":", "") + ".docx")
    print("------------------------- Complete create file word ---------------------\n")
    print("|---------------------------------> OK <---------------------------------|\n")
