import os
import argparse
from PIL import Image

DEFAULT_SIZE = (550, 320)

def resize_image(input_dir, infile, output_dir="resized", size=DEFAULT_SIZE):
    outfile = os.path.splitext(infile)[0] + "_resized"
    extension = os.path.splitext(infile)[1]

    try:
        img = Image.open(input_dir + '/' + infile)
        width, height = img.size
        ratio = width / height
        new_width = size[0]
        new_height = int(round(size[0] / ratio,0))
        # (new_width, new_height) = (size[0],  size[0] / ratio)
        # print((new_width, new_height))
        img = img.resize((new_width, new_height), Image.LANCZOS)
        new_file = output_dir + "/" + outfile + extension
        img.save(new_file)
    except IOError:
        print("unable to resize image {}".format(infile))


if __name__ == "__main__":
    dir = os.getcwd()

    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input_dir', help='Full Input Path')
    parser.add_argument('-o', '--output_dir', help='Full Output Path')

    parser.add_argument('-w', '--width', help='Resized Width')
    parser.add_argument('-t', '--height', help='Resized Height')

    args = parser.parse_args()

    if args.input_dir:
        input_dir = args.input_dir
    else:
        input_dir = dir + '/images'

    if args.output_dir:
        output_dir = args.output_dir
    else:
        output_dir = dir + '/resized'

    if args.width and args.height:
        size = (int(args.width), int(args.height))
    else:
        size = DEFAULT_SIZE

    if not os.path.exists(os.path.join(dir, output_dir)):
        os.mkdir(output_dir)

    try:
        # dir_list = os.listdir(input_dir)
        # print(input_dir)
        directory_list = list()
        for root, dirs, files in os.walk(input_dir, topdown=False):
            for name in dirs:
                directory_list.append(name)
        # print (directory_list)

        for child_dir in directory_list:
            sub = '/' + child_dir
            for file in os.listdir( input_dir +sub):
                if not os.path.exists(os.path.join(dir, output_dir + sub)):
                    os.mkdir(output_dir + sub)
                resize_image(input_dir + sub, file, output_dir +sub, size=size)

        # for file in os.listdir(input_dir):
        #     resize_image(input_dir, file, output_dir, size=size)
    except OSError:
        print('file not found')