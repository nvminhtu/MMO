from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from time import sleep


def mini_screenshot():
    driver = webdriver.Chrome()
    driver.get("https://www.google.com/")
    elem = driver.find_element_by_name("q")
    elem.send_keys("web design")
    elem.send_keys(Keys.ENTER)
    sleep(5)
    driver.get_screenshot_as_file("screenshot.png")
    driver.close()
    print("end...")

def take_fullpage_screenshot():
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--start-maximized')
    driver = webdriver.Chrome(options=chrome_options)
    driver.get("https://www.netlify.com/")
    sleep(2)

    elem = driver.find_element_by_id('main')
    total_height = elem.size["height"]+1000

    driver.set_window_size(1920, total_height) #the trick
    sleep(2)
    driver.save_screenshot("screenshot1.png")
    driver.quit()

if __name__ == "__main__":
    # take_fullpage_screenshot()
    mini_screenshot()