from docx2pdf import convert

convert("doc1.docx")