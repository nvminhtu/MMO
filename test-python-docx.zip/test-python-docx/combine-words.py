from docxcompose.composer import Composer
from docx import Document

doc1 = Document("doc1.docx")
composer = Composer(doc1)
doc2 = Document("doc2.docx")
composer.append(doc1)
composer.save("combined.docx")