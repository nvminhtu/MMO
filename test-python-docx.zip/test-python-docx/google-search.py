
import tldextract
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from time import sleep
try: 
    from googlesearch import search 
except ImportError:  
    print("No module named 'google' found") 
  
def read_keywords():
    with open('keywords.txt','r') as line:
        for keyword in line:
            query_keywords(keyword)

def query_keywords(query):
    for j in search(query, tld="com", num=10, stop=10, pause=2):
        info = tldextract.extract(j)
        # info.registered_domain
        take_fullpage_screenshot('https://www.sortlist.com/')

def take_fullpage_screenshot(url):
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--start-maximized')
    driver = webdriver.Chrome(options=chrome_options)
    driver.get(url)
    sleep(2)

    elem = driver.find_element_by_tag_name('body')
    total_height = elem.size["height"]+1000

    driver.set_window_size(1920, total_height) #the trick
    sleep(2)
    driver.save_screenshot("screenshot1.png")
    driver.quit()

if __name__ == "__main__":
    read_keywords()
    # query_keywords("Web Design in Saigon")
    # query_keywords("SEO service in Saigon")