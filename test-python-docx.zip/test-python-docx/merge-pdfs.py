from PyPDF2 import PdfFileMerger
from os import listdir


input_dir = "C:/Users/MINHTU/Desktop/test-python-docx/" #your input directory path


merge_list = []

for x in listdir(input_dir):
    if not x.endswith('.pdf'):
        continue
    merge_list.append(input_dir + x)

merger = PdfFileMerger()

for pdf in merge_list:
    merger.append(pdf)

merger.write("C:/Users/MINHTU/Desktop/test-python-docx/merged_pdf.pdf") #your output directory
merger.close()