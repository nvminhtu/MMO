# Horizontal Timeline

An easy to customize, horizontal timeline powered by CSS and JavaScript.

[Article on CodyHouse](http://codyhouse.co/gem/horizontal-timeline)

[Demo](https://codyhouse.co/demo/horizontal-timeline)
 
[License](https://codyhouse.co/license)

## Dependencies

This experiment is built upon the [CodyHouse Framework](https://github.com/CodyHouse/codyhouse-framework).

Make sure to include both the style.scss and util.js files of the framework.