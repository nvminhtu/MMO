/**
 * @function customMenu
 * @param: no
 * @note: click menu text to expand full menu list
*/
;(function($){
    "use strict";
    let customMenu;

    $(function() {
       customMenu();
    })
    customMenu = function() {
        let divMouseDown,
        wrapExpandMenu = $('.cd-expand-menu'),
        openIconMenu =  $('.cd-static-menu'),
        closeIconMenu =  $('.cd-expand-menu .menu');

        openIconMenu.on( "click", function( event ) {
            if($(this).hasClass('menu--active')) {
                $(this).removeClass('menu--active');
                wrapExpandMenu.removeClass('menu--active');
                divMouseDown = setTimeout(function() {
                    $('.cd-expand-menu--check').prop('checked', false );
                }, 500);
            } else {
                $(this).addClass('menu--active');
                wrapExpandMenu.addClass('menu--active');
                divMouseDown = setTimeout(function() {
                    $('.cd-expand-menu--check').prop('checked', true );
                }, 500);
            }
        });

        closeIconMenu.on( "click", function( event ) {
            wrapExpandMenu.removeClass('menu--active');
            openIconMenu.removeClass('menu--active');
        });
    }
})(jQuery)