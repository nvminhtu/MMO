/**
 * @description: Javascript for custom theme 
 * @function: hoverVideoSlide
 * @note: all js files for custom script
*/
;(function($){
    "use strict";
    var hoverVideoSlide,
        hoverGallery;
    $(function(){
       hoverVideoSlide();
       hoverGallery();
    });

    hoverVideoSlide = function() {
        $('.cd-main-slideshow').on({
            mouseenter: function () {
                $(this).addClass('hover-bg');
                $(this).find('.cd-main-slideshow_title-intro').addClass('mt-style--tiktok');
            },
            mouseleave: function () {
                $(this).removeClass('hover-bg');
                $(this).find('.cd-main-slideshow_title-intro').removeClass('mt-style--tiktok');
            }
        });
    },

    hoverGallery = function() {
        var defaultImage = $('#me-group-companies-intro .default-slide'),
            targetImageItem = $('#me-group-companies-intro img.me-group-companies__list-item'),
            controlItems = $('#me-group-companies-logo span');

        controlItems.on({
            mouseenter: function () {
                targetImageItem.removeClass('active');
                var transImage = $(this).index();
                // control
                controlItems.removeClass('selected');
                $(this).addClass('selected');
                $(this).find('img').attr("src", $(this).find('img').attr("src").replace(".png", "-active.png"));

                // transition image
                targetImageItem.eq(transImage).addClass('active');
                defaultImage.removeClass('active');
            },
            mouseleave: function () {
                var transImage = $(this).index();
                $(this).find('img').attr("src", $(this).find('img').attr("src").replace("-active.png", ".png"));
                targetImageItem.eq(transImage).removeClass('active');
                defaultImage.addClass('active');
            }
        });
    };
})(jQuery)