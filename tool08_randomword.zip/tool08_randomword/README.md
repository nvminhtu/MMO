# TOOL 08: RANDOM FILE PROPERTIES & ATTRIBUTE

## INSTALLATION
* Code base in [pythond-docx](https://python-docx.readthedocs.io/en/latest/user/install.html)
* Run this command line to install python-docx `pip install python-docx`

## Step 1: Remove PROGRAM NAME
* Select All File -> Right Click Properties => choose Tab `Details`
* Select `Remove Properties and personal Information`

## Step 2: Change Author, Created Date Time,....
* Copy & Paste Word files to under `docs` folder
* Right click to run Git Bash then type command line as below
`python autodoc.py`
