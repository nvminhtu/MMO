from docx import Document
from docx.shared import Inches
from docx.opc.coreprops import CoreProperties
import os
from datetime import datetime
import random
import string
import time

basepath = 'docs/'

#random string
def random_string_generator(str_size, allowed_chars):
    return ''.join(random.choice(allowed_chars) for x in range(str_size))

#random date
def random_date(start, end, prop):
    return str_time_prop(start, end, '%m/%d/%Y %I:%M %p', prop)

def str_time_prop(start, end, format, prop):
    """Get a time at a proportion of a range of two formatted times.

    start and end should be strings specifying times formated in the
    given format (strftime-style), giving an interval [start, end].
    prop specifies how a proportion of the interval to be taken after
    start.  The returned time will be in the specified format.
    """

    stime = time.mktime(time.strptime(start, format))
    etime = time.mktime(time.strptime(end, format))

    ptime = stime + prop * (etime - stime)

    return time.strftime(format, time.localtime(ptime))


def random_date(start, end, prop):
    return str_time_prop(start, end, '%m/%d/%Y %I:%M %p', prop)



with os.scandir(basepath) as entries:
    for entry in entries: #read files from a folder
        if entry.is_file():

            path_doc = basepath + str(entry.name)
            doc = Document(path_doc)

            core_properties = doc.core_properties
            core_properties.comments = ''

            # datetime
            now = datetime.now()
            dt_string = now.strftime("%d/%m/%Y %H:%M:%S")
            created_date = random_date("04/1/2018 1:30 PM", "01/15/2019 4:50 AM", random.random())
            modified_date = random_date("01/16/2019 1:30 PM", "10/16/2019 4:50 AM", random.random())
            created_object = datetime.strptime(created_date, '%m/%d/%Y %I:%M %p')
            modified_object = datetime.strptime(created_date, '%m/%d/%Y %I:%M %p')
            core_properties.created = created_object
            core_properties.modified = modified_object

             # rename files
            chars = string.ascii_letters
            size =  4
            old_name = os.path.splitext(entry.name)[0]
            old_name_arr = old_name.split("_")
            new_name = old_name_arr[0] + '_' + random_string_generator(size, chars) + str(random.randint(1,101)) + '.docx'
            new_path = basepath + str(new_name)

            # author
            new_author_name = random_string_generator(5, 'KTDEIUOAA')
            core_properties.author = new_author_name

            doc.save(path_doc)
            os.rename(path_doc,new_path)