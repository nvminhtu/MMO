import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
from PIL import Image
import os
from pathlib import Path

root= tk.Tk()
root.title('Convert Image Tool')

canvas1 = tk.Canvas(root, width = 300, height = 500, bg = 'lightsteelblue2', relief = 'raised')
canvas1.pack()

label1 = tk.Label(root, text='File Conversion Tool', bg = 'lightsteelblue2')
label1.config(font=('helvetica', 20))
canvas1.create_window(150, 60, window=label1)

def getInput ():
    global indata
    indata = filedialog.askdirectory()
    # indata = Image.open(import_file_path)

browseButton_in = tk.Button(text="      Choose Input Folder  ", command=getInput, bg='royalblue', fg='white', font=('helvetica', 12, 'bold'))
canvas1.create_window(150, 130, window=browseButton_in)

def getOutput ():
    global outdata

    outdata = filedialog.askdirectory()
    # export_file_path = filedialog.asksaveasfilename(defaultextension='.jpg')
    # im1.save(export_file_path)

browseButton_out = tk.Button(text="      Choose Output Folder     ", command=getOutput, bg='royalblue', fg='white', font=('helvetica', 12, 'bold'))
canvas1.create_window(150, 180, window=browseButton_out)

def convertJPG ():
    # print(indata)
    # print(outdata)

    basepath = Path(indata)
    files_in_basepath = (entry for entry in basepath.iterdir() if entry.is_file())
    for item in files_in_basepath:
        outstr = item.name.split('.')
        filein =Image.open(item)
        pathOut = outdata + '/' + outstr[0] + '.jpg'
        filein.save(pathOut)
    # with os.scandir(indata) as entries:
    #     for entry in entries:
    #         if entry.is_file():
    #             # fileIn = indata + '/' + entry.name
    #             fileOut = outdata + '/' + entry.name
    #             entry.save(outdata)

saveAsButton_PNG = tk.Button(text='Convert to JPG', command=convertJPG, bg='royalblue', fg='white', font=('helvetica', 12, 'bold'))
canvas1.create_window(150, 230, window=saveAsButton_PNG)




root.mainloop()