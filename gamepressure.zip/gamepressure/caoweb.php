<?php
require_once('progress/crawl.php');
$title = "Crawl tool to WORD";
?>
<!DOCTYPE html>
<html lang="en-US" class="no-js">
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title><?php echo $title; ?></title>
<meta name="description" content="<?php echo $des; ?>" />
<meta name="keywords" content="<?php echo $keyword; ?>" />
<!-- Mobile viewport -->
<meta name="viewport" content="width=device-width; initial-scale=1.0" />
<link rel="shortcut icon" href="images/favicon.png"  type="image/x-icon" />
<!-- CSS-->
<!-- Google web fonts. You can get your own bundle at http://www.google.com/fonts. Don't forget to update the CSS accordingly!-->
<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic|Oswald:400,300' rel='stylesheet' type='text/css'>
<link rel='stylesheet prefetch' href='https://netdna.bootstrapcdn.com/font-awesome/3.1.1/css/font-awesome.css' />
<link rel="stylesheet" href="css/normalize.css" />
<link rel="stylesheet" href="css/theme.css" />
<link rel="stylesheet" href="css/custom.css" />
<script src="js/spinner/action-spin.js"></script>
<!-- JS-->
<script src="js/libs/modernizr-2.6.2.min.js"></script>
<!-- end JS-->

</head>

<body id="home">

<!-- header area -->
<?php include_once("php/header.php"); ?>
<!-- end header -->

<!-- hero area (the grey one with a slider) -->
    <section id="hero" class="clearfix">
        <div class="wrapper">
            <a href="caoweb.php"><input type="button" class="btnact btna" value="CRAWL WEB" size="150"></a><br />
            <a href="caowebspin.php"><input type="button" class="btnact btnb" value="SPIN WEB + CRAWL"></a>
        </div>
        <div class="wrapper">

            <form action="caoweb.php" method="post">
                <h1 style="background: orange;">CRAWL WEB (CRAWL ONLY)</h1>
                <fieldset>
                    Input link to crawl:<br>
                    <input type="text" name="crawl_site" value="" size="150" /><br /><br />
                    <input type="text" name="title_class" value=".word-txt header h1" size="150" /><br /><br />
                    <input type="text" name="content_class" value=".word-txt" size="150" /><br /><br />
                    <input type="submit" id="get_data" value="Get Data">
                </fieldset>
            </form>

            <div id="crawl-conent">
            <?php
                if(isset($_POST['crawl_site'])) {
                    $out1 = scrape_html($_POST['crawl_site'],$_POST['title_class'],$_POST['content_class']);
                    $title1 = $out1[0];
                    $file_content1 = $out1[1];
                    $url1 = $out1[2];
                    $arrslug = explode('/', $url1);
                    $num = array_pop(array_keys($arrslug));
                    $namefile = str_replace(' ','-',strtolower($title1));
                    $namefile = str_replace(':','',strtolower($namefile));
                    $namefile = str_replace(',','',strtolower($namefile));
                    $namefile = iconv('UTF-8', 'ASCII//TRANSLIT', $namefile);
                }
                ?><br />
                <p>Title: <?php echo $title1; ?></p>
            </div>
            <br />
            <style>
                #content,
                #message {
                    width: 100%;
                    height: 370px;
                    -webkit-box-sizing: border-box;
                    -moz-box-sizing: border-box;
                    box-sizing: border-box;
                    color: #666666;
                    border: 0 none;
                    border-radius: 4px;
                    box-shadow: 0 0 0 0.5em #FFFFFF;
                    background: url(images/note.png) repeat;
                    font: normal 14px verdana;
                    line-height: 25px;
                    padding: 2px 10px;
                    border: solid 1px #ddd;
                    transition: all 0.1s ease-in-out 0s;
                    animation-delay: 250ms;
                    animation-name: slideInRight;
                    animation-duration: 1s;
                    animation-fill-mode: both;
                }
            </style>
    
    <form action="savetofile.php" method="post">
        <div id="index_content">
            <input type="text" id="title" name="title" value="<?php echo $title1; ?>" size="150">
            <input type="text" id="name_file" name="name_file" value="<?php echo $namefile; ?>" size="150"><br><br>
            <textarea name="content" id="content"><?php echo $file_content1; ?></textarea>
        </div>
        <div id="preloader" style="text-align:center;padding: 10px 0 0 0;">
        <img src="images/loading.gif" alt="loading" />
        </div>

            <div class="sp_grid_2">

            <div id="imagever">
            <?php
                    if ($cap_e == "on")
                    {
                    echo '<b>Image verification: </b>';
                    echo '<img src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA" class="imagever">';  
                    echo '<input style="width: 160px;" class="form-control" type="text" id="scode" name="scode"/>';
                    }
                    else
                    {
                    echo '';
                    }
            ?>
            </div>
                </div>
                </div>
            <br /><br /><br /><br />
            <a href="savetofile.php" class="buttonlink">
                <input type="submit" id="export_doc" value="Export to WORD">
            </a>
            <a class="buttonlink" onclick="tryAgain()" id="try_again" href="#">Try Again</a>
        </form>
        </div><!-- end .wrapper div -->
    </section><!-- end hero area -->


<!-- main content area -->   


<!-- footer area -->
<?php include_once("php/footer.php"); ?>
<!-- footer area end-->  

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/libs/jquery-1.9.0.min.js">\x3C/script>')</script>

<!-- fire ups - read this file!  -->   
<script src="js/main.js"></script>
</body>
</html>
