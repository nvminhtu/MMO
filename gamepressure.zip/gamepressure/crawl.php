<?php
/* ##### Step 01: Get File content from web ##### */
require_once "simple_html_dom.php";

function scrape_html($url,$wr_title, $wr_content) {
    // 01. Crawl text from specific website
    $html = file_get_html($url);

    foreach($html->find($wr_title) as $t)
    $title = $t->innertext;
    $title = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $title);

    $title = strip_tags($title,'');

    foreach($html->find($wr_content) as $e)
    $content = $e->innertext;
    $content = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $content);
    $content = preg_replace('#<style(.*?)>(.*?)</style>#is', '', $content);
    $content = preg_replace('#<div class="L_0_2-c">(.*?)</div>#', '', $content);
    // part: trang pressure
    $content = preg_replace('#<div class="social-16">(.*?)</div>#', '', $content);
    $content = preg_replace('#<nav class="guide16-next-prev">(.*?)</nav>#', '', $content);

    $content = str_replace(' src',' no-src',$content);
    $content = str_replace('data-src','src',$content);
    $content = str_replace('src="','src="https://guides.gamepressure.com',$content);

    $data_html = preg_replace('/(<[^>]*) style=("[^"]+"|\'[^\']+\')([^>]*>)/i', '$1$3', $content);
    $data_html = strip_tags($data_html,'<p><ul><li><ol><strong><br><h1><h2><h3><h4><h5><h6><blockquote><img><table><thead><tbody><tr><td><th>');
    $result = '<p>'.$data_html.'</p>';
    // $data_html = $data_html.'<style> p { font-size: 16px; font-family: "Times New Roman", Times, serif; } </style>';

    $out[0] = $title;
    $out[1] = $data_html;
    $out[2] = $url;
    return $out;
}

function removeDomNodes($html, $xpathString) {
    $dom = new DOMDocument;
    $dom->loadHtml($html);

    $xpath = new DOMXPath($dom);
    while ($node = $xpath->query($xpathString)->item(0))
    {
        $node->parentNode->removeChild($node);
    }
    return $dom->saveHTML();
}

?>

