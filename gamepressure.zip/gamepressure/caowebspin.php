<?php
error_reporting(1);
$filename = 'install.php';

if (file_exists($filename)) {
    echo "<br><br><b>Installer detected.. Please wait..</b>";
    header("Location: install.php");
    echo '<meta http-equiv="refresh" content="1;url=install.php">';
    exit();
}
require_once("core/cap.php");
require_once('config.php');
require_once('progress/crawl.php');

$date = date('jS F Y');
$ip = $_SERVER['REMOTE_ADDR'];
$data_ip = file_get_contents('php/ips.tdata');
$con = mysqli_connect($mysql_host,$mysql_user,$mysql_pass,$mysql_database);
$check_site = 1;
$ban_user = 1;

if (mysqli_connect_errno()){
    $sql_error = mysqli_connect_error();
    $check_site = 0;
    goto myoff;
}
    $query =  "SELECT * FROM capthca where id='0'";
    $result = mysqli_query($con,$query);
    while ($row = mysqli_fetch_array($result)) {
        $color =  Trim($row['color']);
        $mode =   Trim($row['mode']);
        $mul =  Trim($row['mul']);
        $allowed =   Trim($row['allowed']);
    }

$_SESSION['captcha'] = elite_captcha($color,$mode,$mul,$allowed);
if (isset($_SESSION['limit_count'])){}
else{
   $_SESSION['limit_count']=0;
}

function str_contains($haystack, $needle, $ignoreCase = false) {
    if ($ignoreCase) {
        $haystack = strtolower($haystack);
        $needle   = strtolower($needle);
    }
    $needlePos = strpos($haystack, $needle);
    return ($needlePos === false ? false : ($needlePos+1));
}
    $query =  "SELECT * FROM site_info";
    $result = mysqli_query($con,$query);
    while($row = mysqli_fetch_array($result)) {
        $title =  Trim($row['title']);
        $des =   Trim($row['des']);
        $keyword =  Trim($row['keyword']);
        $site_name =   Trim($row['site_name']);
        $email =   Trim($row['email']);
        $twit =   Trim($row['twit']);
        $face =   Trim($row['face']);
        $gplus =   Trim($row['gplus']);
        $ga  =   Trim($row['ga']);
    }
    
    $query =  "SELECT * FROM ban_user";
    $result = mysqli_query($con,$query);
        
    while($row = mysqli_fetch_array($result)) {
        $banned_ip =  $banned_ip."::".$row['ip'];
    }
    if (strpos($banned_ip,$ip) !== false)  {
        $ban_user = 0;
        goto banned_user;
    }
        $query =  "SELECT * FROM capthca WHERE id=".Trim('0');
        $result = mysqli_query($con,$query);
        
        while($row = mysqli_fetch_array($result)) {
        $cap_e =  Trim($row['cap_e']);
        }
    $query =  "SELECT @last_id := MAX(id) FROM page_view";
    
    $result = mysqli_query($con,$query);
    
    while($row = mysqli_fetch_array($result)) {
    $last_id =  $row['@last_id := MAX(id)'];
    }
    
    $query =  "SELECT * FROM page_view WHERE id=".Trim($last_id);
    $result = mysqli_query($con,$query);
    while($row = mysqli_fetch_array($result)) {
        $last_date =  $row['date'];
    }
    if($last_date == $date)
    {
         if (str_contains($data_ip, $ip)) 
        {
            $query =  "SELECT * FROM page_view WHERE id=".Trim($last_id);
            $result = mysqli_query($con,$query);
        
            while($row = mysqli_fetch_array($result)) {
                $last_tpage =  Trim($row['tpage']);
            }
            $last_tpage = $last_tpage +1;
        
          // Already IP is there!  So update only page view.
        $query = "UPDATE page_view SET tpage=$last_tpage WHERE id=".Trim($last_id);
            mysqli_query($con,$query);
        } else {
        $query =  "SELECT * FROM page_view WHERE id=".Trim($last_id);
        $result = mysqli_query($con,$query);
        
        while($row = mysqli_fetch_array($result)) {
            $last_tpage =  Trim($row['tpage']);
            $last_tvisit =  Trim($row['tvisit']);
        }
        $last_tpage = $last_tpage +1;
        $last_tvisit = $last_tvisit +1;
        
        // Update both tpage and tvisit.
        $query = "UPDATE page_view SET tpage=$last_tpage,tvisit=$last_tvisit WHERE id=".Trim($last_id);
        mysqli_query($con,$query);
        file_put_contents('php/ips.tdata',$data_ip."\r\n".$ip); 
        }
    }
    else {
    //Delete the file and clear data_ip
    unlink("php/ips.tdata");
    $data_ip ="";
    
    // New date is created!
    $query = "INSERT INTO page_view (date,tpage,tvisit) VALUES ('$date','1','1')"; 
    mysqli_query($con,$query);
    
    //Update the IP!
    file_put_contents('php/ips.tdata',$data_ip."\r\n".$ip); 
    
    }
    
        $query =  "SELECT * FROM ads WHERE id='1'";
        $result = mysqli_query($con,$query);
        
        while($row = mysqli_fetch_array($result)) {
        $ads_1 =  Trim($row['ads_1']);
        $ads_2 =  Trim($row['ads_2']);
        }
    
?>
<!DOCTYPE html>
<html lang="en-US" class="no-js">
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
<head>
<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
<title><?php echo $title; ?></title>
<meta name="description" content="<?php echo $des; ?>" />
<meta name="keywords" content="<?php echo $keyword; ?>" />
<!-- Mobile viewport -->
<meta name="viewport" content="width=device-width; initial-scale=1.0" />
<link rel="shortcut icon" href="images/favicon.png"  type="image/x-icon" />
<!-- CSS-->
<!-- Google web fonts. You can get your own bundle at http://www.google.com/fonts. Don't forget to update the CSS accordingly!-->
<link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,700,400italic|Oswald:400,300' rel='stylesheet' type='text/css'>
<link rel='stylesheet prefetch' href='https://netdna.bootstrapcdn.com/font-awesome/3.1.1/css/font-awesome.css' />
<link rel="stylesheet" href="css/normalize.css" />
<link rel="stylesheet" href="css/theme.css" />
<link rel="stylesheet" href="css/custom.css" />
<script src="js/spinner/action-spin.js"></script>
<!-- JS-->
<script src="js/libs/modernizr-2.6.2.min.js"></script>
<!-- end JS-->

</head>

<body id="home">

<!-- header area -->
<?php include_once("php/header.php"); ?>
<!-- end header -->

<!-- hero area (the grey one with a slider) -->
    <section id="hero" class="clearfix">
    <div class="wrapper">
            <a href="caoweb.php"><input type="button" class="btnact btna" value="CRAWL WEB" size="150"></a><br />
            <a href="caowebspin.php"><input type="button" class="btnact btnb" value="SPIN WEB + CRAWL"></a>
        </div>
        <div class="wrapper">
            <form action="caowebspin.php" method="post">
                <h1 style="background: yellow;">SPIN WEB + CRAWL</h1>
                <fieldset>
                    Input link to crawl:<br>
                    <input type="text" name="crawl_site" value="" size="150" /><br /><br />
                    <input type="text" name="title_class" value=".word-txt header h1" size="150" /><br /><br />
                    <input type="text" name="content_class" value=".word-txt" size="150" /><br /><br />
                    <input type="submit" id="get_data" value="Get Data">
                </fieldset>
            </form>

            <div id="crawl-conent">
                <?php
                if(isset($_POST['crawl_site'])) {
                    $out1 = scrape_html($_POST['crawl_site'],$_POST['title_class'],$_POST['content_class']);
                    $title1 = $out1[0];
                    $file_content1 = $out1[1];
                    $url1 = $out1[2];
                    $arrslug = explode('/', $url1);
                    $num = array_pop(array_keys($arrslug));
                    $namefile = str_replace(' ','-',strtolower($title1));
                    $namefile = str_replace(':','',strtolower($namefile));
                    $namefile = str_replace(',','',strtolower($namefile));
                    $namefile = iconv('UTF-8', 'ASCII//TRANSLIT', $namefile);
                }
                ?><br />
                <p>Title: <?php echo $title1; ?></p>
            </div>
            <br />
    <style>
        #content,
        #message {
            width: 100%;
            height: 370px;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            color: #666666;
            border: 0 none;
            border-radius: 4px;
            box-shadow: 0 0 0 0.5em #FFFFFF;
            background: url(images/note.png) repeat;
            font: normal 14px verdana;
            line-height: 25px;
            padding: 2px 10px;
            border: solid 1px #ddd;
            transition: all 0.1s ease-in-out 0s;
            animation-delay: 250ms;
            animation-name: slideInRight;
            animation-duration: 1s;
            animation-fill-mode: both;
        }
    </style>
    <form action="savetofile.php" method="post">
        <div id="index_content">
            <input type="text" id="title" name="title" value="<?php echo $title1; ?>" size="150">
            <input type="text" id="name_file" name="name_file" value="<?php echo $namefile; ?>" size="150"><br><br>
        		<!-- responsive FlexSlider image slideshow -->
            <textarea id="message"><?php echo $file_content1; ?></textarea>

                </div><!-- end grid div -->
                <div id="preloader" style="text-align:center;padding: 10px 0 0 0;">
                <img src="images/loading.gif" alt="loading" />
                </div>
            <div id="lcontent">
        		<!-- responsive FlexSlider image slideshow -->
                <input type="text" name="title" value="<?php echo $title1; ?>" size="150" />
                <input type="text" id="name_file" name="name_file" value="<?php echo $namefile; ?>" size="150"><br><br>
                <textarea id="content" name="content"></textarea>
            </div><!-- end grid div -->
<br /><br />
<div class="sp_grid_1"> 
<b>Language:</b>
<select class="form-control" id="lang">
  <option value="en" selected="selected">English</option>
  <option value="du">Dutch</option>
  <option value="fr">French</option>
  <option value="sp">Spanish</option>
  <option value="ge">Germany</option>
  <option value="tr">Turkish</option>
  <option value="in">Indonesian</option>
  <option value="vi">Vietnamese</option>
</select> 

</div>

  <div class="sp_grid_2">

<div id="imagever">
<?php
        if ($cap_e == "on")
        {
        echo '<b>Image verification: </b>';
        echo '<img src="' . $_SESSION['captcha']['image_src'] . '" alt="CAPTCHA" class="imagever">';  
        echo '<input style="width: 160px;" class="form-control" type="text" id="scode" name="scode"/>';
        }
        else
        {
         echo ''; 
        }
?>
  </div>
       <div id="failed">
       <div class="callout callout-danger">
        <h4>Oh No!</h4>
       <p>Captcha Code is Wrong.</p>
       </div>
       </div>
    <div id="success">
       <div class="callout callout-success">
        <h4>Wowww Success!</h4>
       <p>Your document successfully spinned.</p>
       </div>
       </div>
       </div>
       <div class="sp_grid_3">
       <div id="try_new">
        <a href="savetofile.php" class="buttonlink">
            <input type="submit" id="export_html" value="Export to HTML">
        </a>
        <a class="buttonlink" onclick="tryAgain()" id="try_again" href="#">Try Again</a>
       </div>
       <div id="spin_new">
            <a href="#" onclick="loadXMLDoc()" id="spin_text" class="buttonlink">Spin</a>
       </div>
       </div></form>
       <br />       <br />
        </div><!-- end .wrapper div -->
    </section><!-- end hero area -->


<!-- main content area -->   


<!-- footer area -->    
<?php include_once("php/footer.php"); ?>
<!-- footer area end-->  

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/libs/jquery-1.9.0.min.js">\x3C/script>')</script>

<!-- fire ups - read this file!  -->   
<script src="js/main.js"></script>

</body>
</html>
<?php
myoff:
if ($check_site == "0")
{
      echo ' 
    <html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" type="image/png" href="images/favicon.png">

        <!-- social network metas -->
        <meta property="site_name" content="Turbo Spinner"/>
        <meta property="description" content="Turbo Spinner: A Article Rewriter" />
        <meta name="description" content="Turbo Spinner: A Article Rewriter" />

        <title>Offline Site - Turbo Spinner: A Article Rewriter</title>
        <!-- bootstrap 3.0.2 -->
        <link href="admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="admin/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="admin/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="admin/css/AdminLTE.css" rel="stylesheet" type="text/css" />

        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
       <body class="skin-blue">
    
    <aside class="right-side strech">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        TurboSpinner
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="caowebspin.php"><i class="fa fa-dashboard"></i> Home</a></li>
                        <li class="active">Offline Site</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                 <br /> <br /> <br />
                    <div class="error-page">
                        <h2 class="headline"></h2>
                        <div class="error-content">
                            <h3><i class="fa fa-warning text-yellow"></i> Oops! SQL ERROR: '.$sql_error.'</h3>
                            <p>
                                Try to fix your site soon. 
                            </p>
                           
                        </div>
                    </div><!-- /.error-page -->

                </section><!-- /.content -->
            </aside>   </body> </html>';  
}
banned_user:
if ($ban_user == "0")
{
      echo ' 
    <html>
    <head>
        <meta charset="UTF-8">
        <link rel="icon" type="image/png" href="img/favicon.ico">

        <!-- social network metas -->
        <meta property="site_name" content="'.$site_name.'"/>
        <meta property="description" content="'.$des.'" />
        <meta name="description" content="'.$des.'" />

        <title>Banned User - '.$title.'</title>
        <!-- bootstrap 3.0.2 -->
        <link href="admin/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <!-- font Awesome -->
        <link href="admin/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
        <!-- Ionicons -->
        <link href="admin/css/ionicons.min.css" rel="stylesheet" type="text/css" />
        <!-- Theme style -->
        <link href="admin/css/AdminLTE.css" rel="stylesheet" type="text/css" />

        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
          <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
        <![endif]-->
    </head>
       <body class="skin-blue">
    
    <aside class="right-side strech">                
                <!-- Content Header (Page header) -->
                <section class="content-header">
                    <h1>
                        '.$site_name.'
                    </h1>
                    <ol class="breadcrumb">
                        <li><a href="caowebspin.php"><i class="fa fa-dashboard"></i> Home </a></li>
                        <li class="active">Banned User</li>
                    </ol>
                </section>

                <!-- Main content -->
                <section class="content">
                 <br /> <br /> <br />
                    <div class="error-page">
                        <h2 class="headline"></h2>
                        <div class="error-content">
                          <h3><i class="fa fa-warning text-yellow"></i> Oops! Access Denied </h3>
                            <p>
                                What happened?<br>
                                The owner of this website has banned your IP address.  
                            </p>
                           
                        </div>
                    </div><!-- /.error-page -->

                </section><!-- /.content -->
            </aside>   </body> </html>';  
}
?>
<?php
mysqli_close($con);
block:
//nothing
?>